<?php defined('SYSPATH') or die('No direct script access.');
/**
 * Login API 
 *
 * @author Rizky Zulkarnaen
 * @version 0.1 
 */
class Controller_Authservice extends Controller_Api_Auth{}	
	