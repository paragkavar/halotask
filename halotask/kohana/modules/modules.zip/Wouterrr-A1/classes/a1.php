<?php defined('SYSPATH') OR die('No direct access allowed.');
 
abstract class A1 extends A1_Core {}