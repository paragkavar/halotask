<?php 

class A1_ORM extends A1_Driver_ORM {}
