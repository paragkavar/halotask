<?php defined('SYSPATH') or die('No direct script access.');

class A1_Sprig extends A1_Driver_Sprig {}
