<?php

class A1_Mango extends A1_Driver_mango {}