<?php defined('SYSPATH') or die('No direct script access.');

class A2_Exception extends Kohana_Exception {}
