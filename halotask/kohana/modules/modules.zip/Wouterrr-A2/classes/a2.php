<?php defined('SYSPATH') OR die('No direct access allowed.');
 
class A2 extends A2_Core {}