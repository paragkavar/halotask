<?php

interface Acl_Role_Interface
{
	/**
	 * Returns the string identifier of the Role
	 *
	 * @return string
	 */
	public function get_role_id();
}
